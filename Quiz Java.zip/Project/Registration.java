import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.awt.event.*; 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.DriverManager;
import java.sql.ResultSet;
class Registration extends JFrame implements ActionListener 
{ 
    private Container c;
    private JLabel title;
    private JLabel fname;
	private JTextField tfname;
    private JLabel lname;
	private JTextField tlname;
	private JLabel rollno;
	private JTextField trollno;
    private JLabel div;
	private JComboBox imca;	
    private JCheckBox term;
    private JButton sub;
    private JButton reset;
	private JTextArea tout;
    private JLabel res;
	private JTextArea resadd;
    private String imcas[]={"IMS","IET","ICA-A","ICA-B"};
    Connection con;
			
    public Registration()
    {
        setTitle("Registration Form");
        setBounds(300, 90, 900, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
 
        c = getContentPane();
        c.setLayout(null);
 
        title = new JLabel("Registration Form");
        title.setFont(new Font("Arial", Font.PLAIN, 30));
        title.setSize(300, 30);
        title.setLocation(300, 30);
        c.add(title);
 
        fname=new JLabel("First Name:");
		fname.setFont(new Font("Arital",Font.PLAIN,20));
		fname.setSize(220,20);
		fname.setLocation(100,100);
		c.add(fname);
		
		tfname=new JTextField();
		tfname.setFont(new Font("Arital",Font.PLAIN,15));
		tfname.setSize(150,20);
		tfname.setLocation(210,100);
		c.add(tfname);
 
        lname=new JLabel("Last Name:");
		lname.setFont(new Font("Arital",Font.PLAIN,20));
		lname.setSize(220,20);
		lname.setLocation(100,150);
		c.add(lname);
		
		tlname=new JTextField();
		tlname.setFont(new Font("Arital",Font.PLAIN,15));
		tlname.setSize(150,20);
		tlname.setLocation(210,150);
		c.add(tlname);
		
		rollno=new JLabel("Roll No.:");
		rollno.setFont(new Font("Arital",Font.PLAIN,20));
		rollno.setSize(220,20);
		rollno.setLocation(100,200);
		c.add(rollno);
		
		trollno=new JTextField();
		trollno.setFont(new Font("Arital",Font.PLAIN,15));
		trollno.setSize(50,20);
		trollno.setLocation(210,200);
		c.add(trollno);
 
        div=new JLabel("Division:");
		div.setFont(new Font("Arital",Font.PLAIN,20));
		div.setSize(220,20);
		div.setLocation(100,250);
		c.add(div);
 
        imca=new JComboBox(imcas);
		imca.setFont(new Font("Arital",Font.PLAIN,15));
		imca.setSize(70,20);
		imca.setLocation(210,250);
		c.add(imca);

        term = new JCheckBox("Accept Terms And Conditions.");
        term.setFont(new Font("Arial", Font.PLAIN, 15));
        term.setSize(250, 20);
        term.setLocation(100, 300);
        c.add(term);
 
        sub = new JButton("Submit");
        sub.setFont(new Font("Arial", Font.PLAIN, 15));
        sub.setSize(100, 20);
        sub.setLocation(100, 350);
        sub.addActionListener(this);
        c.add(sub);
 
        reset = new JButton("Reset");
        reset.setFont(new Font("Arial", Font.PLAIN, 15));
        reset.setSize(100, 20);
        reset.setLocation(240, 350);
        reset.addActionListener(this);
        c.add(reset);
		
		tout = new JTextArea();
        tout.setFont(new Font("Arial", Font.PLAIN, 15));
        tout.setSize(300, 400);
        tout.setLocation(500, 100);
        tout.setLineWrap(true);
        tout.setEditable(false);
        c.add(tout);
 
        res = new JLabel("");
        res.setFont(new Font("Arial", Font.PLAIN, 20));
        res.setSize(500, 25);
        res.setLocation(100, 500);
        c.add(res);
		
		resadd = new JTextArea();
        resadd.setFont(new Font("Arial", Font.PLAIN, 15));
        resadd.setSize(200, 75);
        resadd.setLocation(580, 175);
        resadd.setLineWrap(true);
        c.add(resadd);
 
        setVisible(true);
    }
    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource() == sub) 
		{
            if (term.isSelected()) 
			{
                String data
                    = "First Name : "+ tfname.getText() + "\n"+
                      "Last Name : "+ tlname.getText() + "\n";
					  					  
				String data1="Roll No.:"+trollno.getText()+"\n";
                
                String data2="Division:"+(String)imca.getSelectedItem()+"\n";
							tout.setText(data + data1 + data2);
							tout.setEditable(false);
							res.setText("Registration Successfully.....");

                            try {
								//Class.forName("com.mysql.cj.jdbc.Driver");
                                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "");
                                String FirstName = tfname.getText();
                                String  LastName = tlname.getText();
                                String   RollNo = trollno.getText();
            
                                PreparedStatement prep = con.prepareStatement("INSERT INTO registration(firstname,lastname,rollno) VALUES(?, ?, ?)");
                                prep.setString(1, FirstName);
                                prep.setString(2, LastName);
                                prep.setString(3, RollNo);
                
                                prep.executeUpdate();
                
                
                            } catch (Exception e1) {
                                System.out.println(e1);
                            }           

                              
                
              Quiz q=new Quiz();
              this.setVisible(false);
                
            }
            else 
			{
				tout.setText("");
				resadd.setText("");
                res.setText("Please accept the" + " terms & conditions..");
            }
        } 
        else if (e.getSource() == reset) 
		{
            String def = "";
            tfname.setText(def);
            tlname.setText(def);
			trollno.setText(def);
            res.setText(def);
			tout.setText(def);
            term.setSelected(false);
            imca.setSelectedIndex(0);
			resadd.setText(def);
        }
    }

   public static void main(String[] args) throws Exception
    {
        new Registration();
    }
}